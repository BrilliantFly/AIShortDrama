# 动漫分离采样的显式隔离导出

普通提示词副本：[本目录原版→普通版对照](../../PLAIN_PROMPTS.md#56-face-refine-splitisolated-delivery-exp)。本目录 `*_普通提示词.json` 按原功能、采样和阶段命名，与原图同目录。完整描述一次填写，各阶段可分别编辑；原图保留。

本目录仅新增完整采样／保存 Stage 与零采样冷交付两张 EXP 图；不替换上级目录的 84 张图。两侧采用同一已有隔离 H.264/AAC 导出节点，外置 EAV 默认 report-only，Prompt Relay、原采样及来源音频路径保留。

冷图必须填写完整图该 job 的确切 Stage 路径和 SHA，并保持源视频与配方不变。一次真实原生画布执行副本已验证十二步 full／零步 cold 的完整 124 帧音画同值；不是任意素材、这两张新图的可见编辑重开或人工画质认证，原普通编码失败不改判。

详见[使用方法及验收边界](../../../../docs/FACE_ANIME_ISOLATED_DELIVERY_EXP.md)。
