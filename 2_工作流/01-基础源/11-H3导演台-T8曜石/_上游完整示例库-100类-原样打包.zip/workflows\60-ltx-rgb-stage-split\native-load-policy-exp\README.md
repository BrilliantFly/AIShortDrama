# 可选一致流式加载（EXP）

普通提示词副本：[本目录原版→普通版对照](../../PLAIN_PROMPTS.md#60-ltx-rgb-stage-splitnative-load-policy-exp)。本目录 `*_普通提示词.json` 按原功能、采样和阶段命名，与原图同目录。完整描述一次填写，各阶段可分别编辑；原图保留。

短名入口：[Ordinary Full](S27_LTX25_Ordinary_full_save_eav_relay_native_EXP.json)／[Ordinary Cold](S27_LTX25_Ordinary_resume_ltx_eav_relay_native_EXP.json)／[Identity Full](S27_LTX25_Identity_Preserve_full_save_eav_relay_native_EXP.json)／[Identity Cold](S27_LTX25_Identity_Preserve_resume_ltx_eav_relay_native_EXP.json)。仅重命名、原字节不变，旧名见[对照表](../../filename-map.tsv)。

四张新增图对应普通／Identity 的 full-save 和 cold-LTX；旧图未覆盖。

`LTX · Native Load Policy` 明确选择 `consistent_streaming_exp`，可自行切回 `legacy_default`；观察节点只报告准备调用，不认证采样完成或缓存。

完整图选自己的原视频，并明确开启 Source Save。冷图填同一任务保存得到的 manifest 路径和 SHA，保持模型、LoRA、几何、提示词等一致；它只恢复输入，仍重跑原三步。EAV／Relay 在独立节点中，保留原 `report_only` 默认，实际效果需显式开启。

新模式可能改变旧混合驻留 LoRA 的舍入结果，不保证旧输出同值、任何后端同值或普遍提速。一条 Identity＋EAV／Relay apply-exp 已完成真实画布 full／fresh cold 完整画音精确一致验收，不等于四预设全部素材或质量认证。详见 [用法与验收范围](../../../../docs/LTX_NATIVE_LOAD_POLICY_EXP.md)。
